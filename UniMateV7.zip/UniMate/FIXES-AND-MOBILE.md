# UniMate — Bug Fixes and the Mobile Plan

---

## Part 1 — What was actually broken

I read the code rather than guessing. Seven real defects, each with the reason it
produced the symptom you saw.

| # | Symptom you reported | Real cause | Fix |
|---|---|---|---|
| A | **Admin shows nothing** — no users, no listings | `User` had no `role` **field**; `getRole()` was only a method. Gson serialises fields, so the JSON reaching the browser had no `role` at all | `role` and `dashboardPath` are now real fields set through the constructor. Polymorphism still works, and the JSON now carries them |
| B | **Admin reject button does nothing** | `admin.js` calls `rejectUser`, but `AdminServlet` had no `case "rejectUser"` — the server replied *400 Unknown action* | Case added; rejecting sets the account to `BLOCKED` |
| C | **File upload / download fails** | Files were written to `getServletContext().getRealPath("/")` — Tomcat's exploded temp folder. Every republish deletes it, so downloads 404 | Uploads now go to a fixed folder, `C:\unimate-uploads\`. A missing file returns a readable message instead of a stack trace |
| D | **Product photo cannot be uploaded** | It was never built — no form field, no database column, no servlet handling | Full photo support added: `photo` column, `@MultipartConfig`, file-type check, a `?action=photo` endpoint, thumbnails in the grid and on the product page |
| E | **Product does not get added** | `Double.parseDouble` on a blank price threw `NumberFormatException` → 500, and the form looked dead | Safe parsing plus real validation: empty title or price ≤ 0 now returns a clear message |
| G | **AI chat does not work** | `AIServlet` only counted word overlap with material *titles*. No model was ever contacted | New `AIService` calls a real language model. See Part 2 |
| H | AI always says "nothing found" | It searched only the student's enrolled courses | Falls back to every course when the student has no enrolment |

### One migration to run

If your database already exists, run this once — it adds the photo column:

```sql
USE unimate;
ALTER TABLE market_items ADD COLUMN photo VARCHAR(120) AFTER seller_id;
```

The file is in `database/migration-add-photo.sql`.

---

## Part 2 — Turning the AI on

`src/com/unimate/util/AIService.java` has one line to fill in:

```java
private static final String API_KEY = "";      // paste your key here
```

1. Go to **aistudio.google.com/apikey**
2. Sign in with a Google account and create a key — the free tier is enough for a demo
3. Paste it, save, restart Tomcat

**With no key the screen still works.** It replies with the closest matching material
and a note, so a live demo never shows a blank chat. That is deliberate: an API call
can fail on conference wifi, and you do not want that during your defence.

---

## Part 3 — Making it a mobile app

You are right that this was always meant to be a mobile app. Here is the honest position.

### What you already have going for you

- The servlet API returns **JSON** — the backend needs no changes.
- The CSS is written at **phone width** — the screens already look like an app.
- All 15 screens were designed as mobile screens.

### The three routes

| Route | What it means | Time | Result |
|---|---|---|---|
| **Capacitor wrap** | Your existing HTML/CSS/JS is packaged into a real Android app | 1–2 days | A genuine installable **APK** |
| **Android native (Java)** | Rebuild all 16 screens as Activities | 3–4 weeks | Best performance, matches your Java skill |
| **Flutter** | Rebuild in Dart | 3–4 weeks | Cross platform, but a new language |

### My recommendation: Capacitor

For your remaining time this is the only route that ends with an APK in your hand.
It is not a shortcut you have to apologise for — Capacitor apps ship on the Play Store
every day, and the result is a real native package, not a bookmark.

### Two things that must change first

**1. The backend has to be reachable from a phone.**
`localhost` means the phone itself, so it will find nothing. Deploy the WAR to a free
host (Railway, Render, or Koyeb all take a Tomcat WAR), then point the app at that URL.

**2. The session cookie has to survive.**
The app runs from `file://` inside the WebView, so the browser will not attach your
`JSESSIONID` cookie to a call going to another domain. Two ways round it:

- Set `withCredentials` on every fetch and enable CORS with credentials on the server, or
- Switch the session to a token: return a token at login, store it in the app, send it
  as a header. This is the cleaner fix and is roughly 40 lines across `LoginServlet`
  and `AuthFilter`.

### The steps, once the backend is deployed

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init UniMate com.unimate.app --web-dir=WebContent
npx cap add android
npx cap sync
npx cap open android      # opens Android Studio, then Build > Build APK
```

You will also need **Android Studio** and the Android SDK installed.

### What I suggest you do

Finish and submit the web version first — it is 75% done and the deadline is close.
Get the marks. Then take the mobile conversion as Sprint 6 with a clear head, because
deploying the backend and swapping the session to tokens both deserve proper testing.

A working web app submitted on time beats a half-converted mobile app submitted late.


## Approval workflow update
- New student and instructor registrations are PENDING until admin approval.
- Instructor materials are PENDING until admin approval.
- Students only receive LIVE materials.
- Admin dashboard now includes a Materials queue.
- Run database/migration-add-approval-workflow.sql once on an existing database.
