# UniMate — Complete Project Handover

**Course:** CSE 327 — Software Engineering, North South University
**Team:** Md. Ashikur Rahman Siyam · Shudarshan Ghosh Durjoy

A campus app for university students in Bangladesh: courses, study materials, study
groups, an internship board, a student marketplace and a study assistant.

**Stack:** HTML · CSS · JavaScript (no framework) → Java Servlets (Jakarta) → MySQL, on Tomcat 10.

---

## 1. Everything installed on the machine

These were downloaded and installed while setting the project up. Anyone rebuilding the
environment needs the same list.

| # | Software | Version used | Where it came from | Why |
|---|---|---|---|---|
| 1 | **JDK** | OpenJDK 17 (Temurin) | adoptium.net | Compiles and runs the Java code |
| 2 | **Eclipse IDE for Enterprise Java and Web Developers** | 2026-06 | eclipse.org/downloads/packages | The plain "Java Developers" package does **not** have Dynamic Web Project |
| 3 | **Eclipse Enterprise Java and Web Developer Tools** | 3.42 | Eclipse Marketplace | Added afterwards because the wrong Eclipse package was installed first |
| 4 | **Apache Tomcat** | 10.1.57, 64-bit Windows **zip** | tomcat.apache.org | Servlet container. Extracted to `C:\apache-tomcat-10.1.57-windows-x64\apache-tomcat-10.1.57` |
| 5 | **Visual C++ 2019 Redistributable** | x64 | aka.ms/vs/17/release/vc_redist.x64.exe | MySQL Server and Workbench both refuse to install without it |
| 6 | **MySQL Server** | 26.7 | dev.mysql.com | The database |
| 7 | **MySQL Workbench** | 8.0.47 CE | dev.mysql.com | GUI for running the SQL scripts |
| 8 | **MySQL Connector/J** | `mysql-connector-j-26.7.0.jar` | dev.mysql.com → Platform Independent ZIP | JDBC driver. Goes in `WebContent/WEB-INF/lib/` |
| 9 | **Gson** | `gson-2.11.0.jar` | mvnrepository.com | Turns Java objects into JSON. Goes in `WebContent/WEB-INF/lib/` |

**Important choices made along the way**

- Tomcat **10**, not 9 — the code uses `jakarta.servlet`. Tomcat 9 would need every import changed to `javax.servlet`.
- The **zip** build of Tomcat, not the Windows Service Installer — the service version fights with Eclipse.
- Dynamic web module version **5.0** — matches Tomcat 10. Eclipse defaults to 6.0, which is Tomcat 11.
- Eclipse's **JavaScript Validator was switched off** (Project → Properties → Validation). It reported 630 false errors because the old ES5 validator does not understand template literals, arrow functions or `async/await`. None were real.

---

## 2. Eclipse project settings

Created as **Dynamic Web Project** with:

| Setting | Value |
|---|---|
| Project name | `UniMate` |
| Target runtime | Apache Tomcat v10.1 |
| Dynamic web module version | 5.0 |
| Source folder | `src` (the default `src/main/java` was removed) |
| Content directory | `WebContent` (the default `src/main/webapp` was replaced) |
| Generate web.xml | unticked — the project ships its own |

Both JARs are in `WebContent/WEB-INF/lib/` and on the build path.

---

## 3. Full file structure

```
UniMate/
│
├── README.md                        how to run the project
├── FIXES-AND-MOBILE.md              the 7 bugs found, and the mobile plan
├── .gitignore
│
├── WebContent/                      everything the browser loads
│   │
│   ├── index.html                   login              (screen 01)
│   ├── signup.html                  registration       (screen 02)
│   │
│   ├── student/
│   │   ├── dashboard.html           counters, my courses, my groups   (03)
│   │   ├── courses.html             course list with search           (04)
│   │   ├── course-detail.html       overview + materials tabs         (05)
│   │   ├── groups.html              study group list                  (06)
│   │   ├── group-detail.html        one group                         (07)
│   │   ├── create-group.html        new group form
│   │   ├── board.html               internships and scholarships      (08)
│   │   ├── marketplace.html         item grid                         (10)
│   │   ├── product.html             one item                          (11)
│   │   ├── sell.html                post an item, with photo upload
│   │   ├── profile.html             account details                   (12)
│   │   └── ai.html                  study assistant chat              (15)
│   │
│   ├── instructor/
│   │   └── dashboard.html           my courses + material upload      (13)
│   │
│   ├── admin/
│   │   └── dashboard.html           approve sign-ups and listings     (14)
│   │
│   ├── css/
│   │   ├── style.css                design tokens, layout, pages
│   │   └── components.css           buttons, cards, chips, tabs, nav
│   │
│   ├── js/                          one file per feature
│   │   ├── api.js                   fetch wrapper, base URL, 401 handling
│   │   ├── ui.js                    escaping, formatting, alerts, nav
│   │   ├── auth.js                  login, signup, logout
│   │   ├── courses.js               dashboard, course list, detail, materials
│   │   ├── groups.js                group list, detail, create, join
│   │   ├── market.js                marketplace, product, sell, photos
│   │   ├── board.js                 opportunity board and filters
│   │   ├── profile.js               profile screen
│   │   ├── instructor.js            instructor dashboard and upload
│   │   ├── admin.js                 admin console and approvals
│   │   └── ai.js                    assistant chat
│   │
│   ├── assets/images/               logo and pictures
│   │
│   └── WEB-INF/
│       ├── web.xml                  welcome file only; servlets use annotations
│       └── lib/
│           ├── mysql-connector-j-26.7.0.jar     ← you add this
│           └── gson-2.11.0.jar                  ← and this
│
├── src/com/unimate/                 all Java, 35 files
│   │
│   ├── model/                       plain data classes
│   │   ├── User.java                ABSTRACT. role and dashboardPath are real fields
│   │   ├── Student.java             extends User
│   │   ├── Instructor.java          extends User
│   │   ├── Admin.java               extends User
│   │   ├── Course.java
│   │   ├── Material.java
│   │   ├── StudyGroup.java
│   │   ├── MarketItem.java          includes the photo field
│   │   └── Opportunity.java
│   │
│   ├── dao/                         every SQL statement lives here
│   │   ├── DBConnection.java        the only class that opens a connection
│   │   ├── BaseDAO.java             generic interface all DAOs implement
│   │   ├── UserDAO.java             builds the right subclass from the role column
│   │   ├── CourseDAO.java           search, enrol, by student, by instructor
│   │   ├── MaterialDAO.java
│   │   ├── GroupDAO.java
│   │   ├── MarketDAO.java
│   │   └── OpportunityDAO.java
│   │
│   ├── servlet/                     one servlet per feature
│   │   ├── BaseServlet.java         ABSTRACT. sendJson, sendError, currentUser
│   │   ├── RegisterServlet.java     /register
│   │   ├── LoginServlet.java        /login
│   │   ├── LogoutServlet.java       /logout
│   │   ├── ProfileServlet.java      /profile
│   │   ├── CourseServlet.java       /courses
│   │   ├── MaterialServlet.java     /materials    multipart upload + download
│   │   ├── GroupServlet.java        /groups
│   │   ├── MarketServlet.java       /marketplace  multipart photo + serving
│   │   ├── OpportunityServlet.java  /opportunities
│   │   ├── AdminServlet.java        /admin
│   │   └── AIServlet.java           /ai
│   │
│   ├── filter/
│   │   └── AuthFilter.java          guards /student/*, /instructor/*, /admin/*
│   │
│   └── util/
│       ├── Constants.java           roles, statuses, upload folders, email domains
│       ├── PasswordUtil.java        SHA-256 hash and compare
│       ├── JsonUtil.java            Gson wrapper
│       ├── AppException.java        one custom exception
│       └── AIService.java           calls the language model; paste the key here
│
├── database/
│   ├── schema.sql                   CREATE TABLE for all 8 tables
│   ├── seed.sql                     31 users, 15 courses, 311 rows total
│   ├── migration-add-photo.sql      adds the photo column to an existing database
│   └── queries.sql                  11 queries used while testing
│
├── uploads/                         placeholder; real files go to C:\unimate-uploads\
└── docs/                            UML diagrams, UI screens, report
```

**Totals:** 35 Java · 16 HTML · 11 JavaScript · 2 CSS · 4 SQL

---

## 4. The eight database tables

| Table | Holds |
|---|---|
| `users` | All three roles in one table with a `role` column |
| `courses` | Code, title, credits, prerequisites, difficulty, instructor |
| `enrollments` | Student ↔ course, with a UNIQUE key so nobody enrols twice |
| `materials` | Notes, slides, past questions, lab files, download counter |
| `study_groups` | Name, course code, university, member limit |
| `group_members` | Group ↔ student |
| `market_items` | Title, price, condition, **photo**, status |
| `opportunities` | Internships, hackathons, scholarships, contests |

**Demo accounts — password `demo1234` for all of them**

| Role | Email | Lands on |
|---|---|---|
| Student | ashiku.siyam@northsouth.edu | `student/dashboard.html` |
| Student | durjoy@northsouth.edu | `student/dashboard.html` |
| Instructor | sabrina@northsouth.edu | `instructor/dashboard.html` |
| Admin | admin@northsouth.edu | `admin/dashboard.html` |

The redirect comes from `User.getDashboardPath()` — one polymorphic call, no if-chain.

---

## 5. How a request flows

```
HTML page  →  js/*.js  →  servlet  →  DAO  →  MySQL
```

Four rules the code follows throughout:

1. An HTML page holds no logic — it links a file from `js/`.
2. A servlet writes no SQL — it calls a DAO.
3. A DAO never touches `request` or `response`.
4. `DBConnection.java` is the only file that opens a connection.

---

## 6. Where the OOP is

| Principle | Where it lives |
|---|---|
| Encapsulation | Every model field is `private` with getters and setters |
| Inheritance | `User` (abstract) → `Student`, `Instructor`, `Admin` |
| Polymorphism | `getDashboardPath()` returns a different page per subclass; `LoginServlet` has no `if` |
| Abstraction | `BaseDAO<T>` interface and the abstract `BaseServlet` |

---

## 7. Setup, in order

1. Install everything in section 1.
2. Put both JARs in `WebContent/WEB-INF/lib/` and add them to the build path.
3. In MySQL Workbench:
   ```sql
   CREATE DATABASE unimate;
   USE unimate;
   ```
   then run `database/schema.sql`, then `database/seed.sql`.
4. Open `src/com/unimate/dao/DBConnection.java` and set `USER` and `PASS`.
5. Optional — to switch the assistant on, paste a key into `src/com/unimate/util/AIService.java`.
   Get one free at aistudio.google.com/apikey. **Without a key the screen still works**, it
   answers from the material list, so a live demo never shows a blank chat.
6. Right click the project → Run As → Run on Server → `http://localhost:8080/UniMate/`

---

## 8. Seven bugs found and fixed during integration

| # | Symptom | Root cause | Fix |
|---|---|---|---|
| A | Admin console showed nothing | `User` had no `role` **field** — only `getRole()`. Gson serialises fields, so the JSON had no role at all | `role` and `dashboardPath` became real fields set through the constructor |
| B | Reject button did nothing | `admin.js` sent `rejectUser`; `AdminServlet` had no such case → 400 | Case added, sets the account to `BLOCKED` |
| C | Upload and download failed | Files were written to `getRealPath("/")`, Tomcat's temp deploy folder, wiped on every republish | Fixed folder `C:\unimate-uploads\`, plus a readable error when a file is missing |
| D | Product photo could not be uploaded | Never built — no column, no form field, no servlet support | Full support: `photo` column, `@MultipartConfig`, file-type check, `?action=photo` endpoint, thumbnails |
| E | Product would not post | `Double.parseDouble` on a blank price threw and returned 500 | Safe parsing plus validation with clear messages |
| G | Assistant did nothing | It only counted word overlap with material titles; no model was contacted | New `AIService` calls a real language model, with an offline fallback |
| H | Assistant always said "nothing found" | It searched only enrolled courses | Falls back to every course when the student has no enrolment |

Two more were caught earlier: `web.xml` had a comment before the XML declaration (invalid
XML, would have stopped Tomcat) and used the wrong namespace for Tomcat 10.

---

## 9. Deliberately out of scope

Designed and documented in the UML, not implemented. Written up as future work.

| Feature | Note |
|---|---|
| Group chat | The group screen shows a placeholder |
| Vector search in the assistant | Material titles are matched instead of embeddings |
| Email verification link | Accounts activate directly |

**Not production ready.** Before real use it would need BCrypt instead of plain SHA-256,
HTTPS, connection pooling, CSRF tokens and upload type validation. These are acknowledged
in the report rather than hidden.

---

## 10. The mobile app

The project is meant to end up as a mobile app. Three things already point that way:

- The servlet API returns **JSON**, so the backend is reusable unchanged.
- The CSS is built at **phone width** (420px column), so screens need no redesign.
- All 15 UI screens were designed as mobile screens from the start.

**Recommended route: Capacitor** — it wraps the existing HTML/CSS/JS into a real
installable APK in about a day.

Two things must change first:

1. **The backend must be reachable from a phone.** `localhost` means the phone itself.
   Deploy the WAR to Railway, Render or Koyeb and point the app at that URL.
2. **The session cookie will not survive.** The app runs from `file://` inside a WebView,
   so `JSESSIONID` will not be attached to a cross-origin call. Either enable CORS with
   credentials, or switch to a token returned at login and sent as a header — roughly
   40 lines across `LoginServlet` and `AuthFilter`.

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init UniMate com.unimate.app --web-dir=WebContent
npx cap add android
npx cap sync
npx cap open android      # then Build > Build APK in Android Studio
```

Android Studio and the Android SDK are also required.

---

## 11. Current state

| Area | Status |
|---|---|
| Database — schema and seed | Done and running |
| Java — models, DAOs, servlets, filter | Written, 35 files |
| Frontend — 16 pages, 11 JS modules, 2 CSS | Written |
| Environment — Eclipse, Tomcat, MySQL, JARs | Working |
| Login and role routing | Verified working |
| The seven bug fixes above | **Written but not yet run** |
| Full walkthrough of every screen | **Not done yet** |
| Report, screenshots, demo video | Not started |
| Mobile conversion | Not started |

**The honest summary: the code is complete, the verification is not.** The next task is
not writing more code — it is running the six checks below and fixing whatever they turn up.

### The six checks that decide whether the backend is finished

1. Admin login → sign-ups and listings both show data
2. Post a marketplace item with a photo
3. Admin approves it → it appears in the grid with the photo
4. Instructor uploads a file
5. Student downloads that same file
6. Assistant answers a question and shows a source card

> Note on check 5: the 20 seeded materials are database rows only — the actual files never
> existed. Clicking Get on those correctly reports the file is missing. Upload one as an
> instructor first, then download that.
