# UniMate

A campus app for university students in Bangladesh — courses, study materials, study
groups, an opportunity board, a student marketplace and a study assistant.

**Team:** Md. Ashikur Rahman Siyam · Shudarshan Ghosh Durjoy
**Course:** CSE 327 — Software Engineering

---

## Stack

| Layer | Technology |
|---|---|
| Frontend | HTML · CSS · JavaScript (no framework) |
| Backend | Java Servlets (Jakarta) |
| Database | MySQL |
| Server | Apache Tomcat 10 |

---

## Running it the first time

### 1. Install
- JDK 17 or newer
- Apache Tomcat **10** (not 9 — the code uses `jakarta.servlet`)
- MySQL 8
- Eclipse IDE **for Enterprise Java and Web Developers**

### 2. Add two JAR files to `WebContent/WEB-INF/lib/`
- `mysql-connector-j-8.x.x.jar`
- `gson-2.x.x.jar`

### 3. Create the database
```sql
CREATE DATABASE unimate;
USE unimate;
SOURCE database/schema.sql;
SOURCE database/seed.sql;
```

### 4. Set your MySQL password
Open `src/com/unimate/dao/DBConnection.java` and edit the `USER` and `PASS` lines.

### 5. Run
Import as a **Dynamic Web Project** (source folder `src`, content folder `WebContent`),
add the two JARs to the build path, then Run As → Run on Server.

```
http://localhost:8080/UniMate/
```

---

## Demo accounts — password `demo1234`

| Role | Email | Lands on |
|---|---|---|
| Student | ashiku.siyam@northsouth.edu | `student/dashboard.html` |
| Student | durjoy@northsouth.edu | `student/dashboard.html` |
| Instructor | sabrina@northsouth.edu | `instructor/dashboard.html` |
| Admin | admin@northsouth.edu | `admin/dashboard.html` |

The redirect is decided by `User.getDashboardPath()` — one call, no `if` chain.

---

## Folder map

```
UniMate/
├── WebContent/               everything the browser loads
│   ├── index.html            login
│   ├── signup.html
│   ├── student/              12 pages
│   ├── instructor/           dashboard + upload
│   ├── admin/                approval console
│   ├── css/                  style.css · components.css
│   ├── js/                   one file per feature
│   └── WEB-INF/web.xml
│
├── src/com/unimate/
│   ├── model/    User (abstract) → Student · Instructor · Admin, plus 5 data classes
│   ├── dao/      BaseDAO interface + 7 DAOs, all SQL lives here
│   ├── servlet/  BaseServlet (abstract) + 10 feature servlets
│   ├── filter/   AuthFilter — guards the three role folders
│   └── util/     PasswordUtil · JsonUtil · Constants · AppException
│
├── database/     schema.sql · seed.sql · queries.sql
└── docs/         UML diagrams, UI screens, report
```

---

## How a request flows

```
HTML page → js/*.js → servlet → DAO → MySQL
```

Four rules that keep it readable:

1. An HTML page holds no logic — it links a file from `js/`.
2. A servlet writes no SQL — it calls a DAO.
3. A DAO never touches `request` or `response`.
4. `DBConnection.java` is the only file that opens a connection.

---

## Where the OOP is

| Principle | Where |
|---|---|
| Encapsulation | every model field is `private` with getters and setters |
| Inheritance | `User` → `Student`, `Instructor`, `Admin` |
| Polymorphism | `getDashboardPath()` and `getRole()` answer differently per subclass |
| Abstraction | `BaseDAO<T>` interface and the abstract `BaseServlet` |

---

## Security

- `AuthFilter` blocks `/student/*`, `/instructor/*`, `/admin/*` by role
- Material download checks `isEnrolled()` **on the server**, not in the UI
- Uploading requires the Instructor role
- Students only ever see marketplace items with status `LIVE`
- Every query uses `PreparedStatement`

---

## v6 changes

- **Enrollment is now request-based.** A student sends a request, the instructor
  approves or rejects it from their dashboard, and only an approved student can see
  and download that course's materials.
- **Group chat is live.** Once a student joins a study group, a chat box opens with
  the member list and messages.
- **Marketplace purchases.** A "Purchase" button asks for confirmation, then marks
  the item SOLD (cash on pickup - no payment gateway needed).
- **Instructors can post opportunities** (internship, hackathon, scholarship, contest)
  from their own dashboard, not just the admin console.
- **Admin can assign instructors to courses** from a new Courses tab.
- **Desktop view fixed.** Below ~900px the app still looks like the phone-card design;
  above it, the same pages fill the browser window instead of staying boxed at 420px.
- **Upload/download fix.** The upload folder no longer points at a hard-coded
  `C:\unimate-uploads` (which needs admin rights on many Windows accounts and only
  works on Windows). It now uses the logged-in user's own home folder, so uploads
  save and downloads succeed on any machine.

If you already have a database, run `database/migration-v6-features.sql` once.
Fresh installs get all of this from `schema.sql` and `seed.sql` directly.

## Known scope limits

Designed and documented, not implemented — written up as future work:

- Group chat (the UI shows a placeholder)
- Vector search in the assistant — `AIServlet` matches material titles instead
- Email verification link (accounts activate directly)
