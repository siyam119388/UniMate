# Running UniMate on a fresh PC

You have VS Code and MySQL. You still need Java and Tomcat. Nothing else.

No IDE project setup is required — three batch files do the compiling and deploying.

---

## 1. Install two things (about 15 minutes)

### JDK 17
- **adoptium.net** → Temurin 17 → Windows x64 → **.msi**
- During install, tick **"Set JAVA_HOME variable"** and **"Add to PATH"**

Check it worked — open Command Prompt:
```
javac -version
```
It should print `javac 17.x.x`. If it says *not recognised*, the PATH box was not ticked; reinstall.

### Tomcat 10
- **tomcat.apache.org** → Tomcat 10 → **64-bit Windows zip**
- Extract to `C:\` so you end up with:
  ```
  C:\apache-tomcat-10.1.57\
      bin\  conf\  lib\  webapps\
  ```
- Do **not** use the Windows Service Installer.

---

## 2. Get the project back

Download `UniMate-Fixed.zip` from the chat again and extract it. Put it somewhere with
no spaces in the path:

```
C:\UniMate\
```

Inside you should see `src`, `WebContent`, `database`, `build.bat`, `run.bat`.

---

## 3. Put the two jars back

They are not in the zip — you download them yourself:

| Jar | Where |
|---|---|
| `mysql-connector-j-*.jar` | dev.mysql.com/downloads/connector/j → **Platform Independent** → ZIP → take the jar out |
| `gson-2.11.0.jar` | mvnrepository.com/artifact/com.google.code.gson/gson → click the version → **jar** |

Both go in:
```
C:\UniMate\WebContent\WEB-INF\lib\
```

---

## 4. Set up the database

Open MySQL Workbench, connect, then run:

```sql
CREATE DATABASE unimate;
USE unimate;
```

Then **File → Open SQL Script** and run, in this order:
1. `C:\UniMate\database\schema.sql`
2. `C:\UniMate\database\seed.sql`

Check it:
```sql
USE unimate;
SELECT COUNT(*) FROM users;
```
You want **31**.

---

## 5. Two small edits in VS Code

Open the `C:\UniMate` folder in VS Code.

**Edit 1 — your MySQL password**
`src/com/unimate/dao/DBConnection.java`, near the top:
```java
private static final String USER = "root";
private static final String PASS = "";     // put your MySQL password here
```

**Edit 2 — your Tomcat path**
Open `build.bat`, `run.bat` and `stop.bat`. Each starts with:
```bat
set TOMCAT=C:\apache-tomcat-10.1.57
```
Change it if your folder name is different.

---

## 6. Run it

Double click **`run.bat`**.

It compiles the Java, copies everything into Tomcat, starts the server and opens the
browser at `http://localhost:8080/UniMate/`.

To stop: close the Tomcat window, or double click `stop.bat`.

**After you change any Java or HTML file, run `run.bat` again.**

---

## Log in

Password for every account: `demo1234`

| Role | Email |
|---|---|
| Student | ashiku.siyam@northsouth.edu |
| Instructor | sabrina@northsouth.edu |
| Admin | admin@northsouth.edu |

---

## If something goes wrong

| Message | What it means |
|---|---|
| `javac is not recognized` | JDK not on PATH. Reinstall with "Add to PATH" ticked |
| `Tomcat not found at ...` | Fix the `set TOMCAT=` line in the batch files |
| `No jars in WebContent\WEB-INF\lib` | Step 3 not done |
| `package jakarta.servlet does not exist` | Tomcat path is wrong, or you have Tomcat 9 instead of 10 |
| `Access denied for user 'root'` | Wrong password in `DBConnection.java` |
| `Unknown database 'unimate'` | Step 4 not done |
| Port 8080 in use | Another Tomcat is running. Run `stop.bat`, or change the port in `conf\server.xml` |

---

## Optional — nicer VS Code editing

These extensions give you Java autocomplete and error checking. They are not needed to
run anything, the batch files handle that.

- **Extension Pack for Java** (Microsoft)
- **MySQL** (Weijan Chen) — browse the database inside VS Code

---

## Why batch files instead of configuring VS Code

VS Code can run servlet projects, but it needs a server connector extension and a fair
amount of configuration that breaks easily. The batch files do exactly what an IDE does —
`javac` then copy to `webapps` — in a way you can read and fix yourself. It is also the
same thing that happens when you deploy to a real server later.
