Put mysql-connector-j.jar and gson.jar here
