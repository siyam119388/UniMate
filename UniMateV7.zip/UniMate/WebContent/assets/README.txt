Put logo and images in this folder
