// admin.js - the admin console

async function loadAdmin() {
  try {
   const d = await API.get(api('admin-api'));
    const pendingUsers = Array.isArray(d.pendingUsers) ? d.pendingUsers : [];
    const pendingItems = Array.isArray(d.pendingItems) ? d.pendingItems : [];
    const pendingMaterials = Array.isArray(d.pendingMaterials) ? d.pendingMaterials : [];
    const courses = Array.isArray(d.courses) ? d.courses : [];
    const instructors = Array.isArray(d.instructors) ? d.instructors : [];

    document.getElementById('totalUsers').textContent = d.totalUsers || 0;
    document.getElementById('pendingCount').textContent = pendingUsers.length;
    document.getElementById('itemCount').textContent = pendingItems.length;
    document.getElementById('materialCount').textContent = pendingMaterials.length;

    const users = document.getElementById('pendingUsers');
    users.innerHTML = pendingUsers.length ? pendingUsers.map(u => `
      <div class="card">
        <div class="card-row">
          <div class="avatar light">${initials(u.name)}</div>
          <div class="grow"><h3>${esc(u.name)}</h3><div class="small">${esc(u.email)} - ${esc(u.role || 'STUDENT')}</div></div>
        </div>
        <div class="btn-row" style="margin-top:11px">
          <button class="btn sm ghost" style="flex:1" onclick="act('rejectUser', ${u.userId})">Reject</button>
          <button class="btn sm" style="flex:1" onclick="act('approveUser', ${u.userId})">Approve</button>
        </div>
      </div>`).join('') : '<div class="empty">No account is waiting.</div>';

    const items = document.getElementById('pendingItems');
    items.innerHTML = pendingItems.length ? pendingItems.map(i => `
      <div class="card">
        <div class="card-row">
          <div class="icon">M</div>
          <div class="grow"><h3>${esc(i.title)}</h3><div class="small">${money(i.price)} - ${esc(i.sellerName || '')}</div></div>
        </div>
        ${i.photo ? `<div class="small" style="margin-top:8px">Photo attached</div>` : ''}
        <div class="btn-row" style="margin-top:11px">
          <button class="btn sm ghost" style="flex:1" onclick="act('removeItem', ${i.itemId})">Remove</button>
          <button class="btn sm" style="flex:1" onclick="act('approveItem', ${i.itemId})">Approve</button>
        </div>
      </div>`).join('') : '<div class="empty">No listing is waiting.</div>';

    const materials = document.getElementById('pendingMaterials');
    materials.innerHTML = pendingMaterials.length ? pendingMaterials.map(m => `
      <div class="card">
        <div class="card-row">
          <div class="icon file">${esc((m.type || 'FILE').slice(0,4))}</div>
          <div class="grow"><h3>${esc(m.title)}</h3><div class="small">${esc(m.courseCode || '')} - ${esc(m.uploaderName || '')}</div></div>
        </div>
        <div class="small" style="margin-top:8px">${esc(m.filePath || '')}</div>
        <div class="btn-row" style="margin-top:11px">
          <button class="btn sm ghost" style="flex:1" onclick="act('rejectMaterial', ${m.materialId})">Reject</button>
          <button class="btn sm" style="flex:1" onclick="act('approveMaterial', ${m.materialId})">Approve</button>
        </div>
      </div>`).join('') : '<div class="empty">No material is waiting.</div>';

    const courseBox = document.getElementById('courseList');
    const instructorOptions = instructors.map(i => `<option value="${i.userId}">${esc(i.name)}</option>`).join('');
    courseBox.innerHTML = courses.length ? courses.map(c => `
      <div class="card">
        <div>
          <span class="tag">${esc(c.code)}</span>
          <span class="tag grey">${c.credits} cr</span>
        </div>
        <h3 style="margin-top:7px">${esc(c.title)}</h3>
        <div class="small" style="margin-top:5px">Current instructor: ${esc(c.instructorName || 'None')}</div>
        <div class="card-row" style="margin-top:11px">
          <select class="input" id="pick-${c.courseId}" style="flex:1;height:38px">
            <option value="">Choose an instructor</option>
            ${instructorOptions}
          </select>
          <button class="btn sm" onclick="assignInstructor(${c.courseId})">Assign</button>
        </div>
      </div>`).join('') : '<div class="empty">No course found.</div>';

  } catch (err) {
    setEmpty('pendingUsers', err.message);
    setEmpty('pendingItems', err.message);
    setEmpty('pendingMaterials', err.message);
    setEmpty('courseList', err.message);
  }
}

async function act(action, id) {
  try { await API.post(api('admin-api'), { action: action, id: id }); await loadAdmin(); }
  catch (err) { alert(err.message); }
}

async function assignInstructor(courseId) {
  const select = document.getElementById('pick-' + courseId);
  const instructorId = select.value;
  if (!instructorId) { alert('Choose an instructor first'); return; }
  try {
    await API.post(api('admin-api'), { action: 'assignInstructor', courseId: courseId, instructorId: instructorId });
    await loadAdmin();
  } catch (err) { alert(err.message); }
}

function showAdminTab(name, el) {
  document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('on'));
  el.classList.add('on');
  ['usersTab', 'itemsTab', 'materialsTab', 'coursesTab'].forEach(id => document.getElementById(id).classList.toggle('hidden', id !== name));
}
