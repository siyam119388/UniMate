// instructor.js - instructor dashboard, material upload, enrollment approval, opportunities

async function loadInstructor() {
  document.getElementById('userName').textContent = sessionStorage.getItem('name') || 'Instructor';
  document.getElementById('avatar').textContent   = initials(sessionStorage.getItem('name'));

  try {
    const courses = await API.get(api('courses'), { action: 'teaching' });

    document.getElementById('statCourses').textContent = courses.length;
    document.getElementById('statStudents').textContent =
      courses.reduce((sum, c) => sum + (c.enrolledCount || 0), 0);

    // fill the course picker on the upload form
    const select = document.getElementById('courseId');
    if (courses.length) {
      select.innerHTML = courses.map(c =>
        `<option value="${c.courseId}">${esc(c.code)} - ${esc(c.title)}</option>`).join('');
    } else {
      select.innerHTML = '<option value="0">You do not own a course yet</option>';
      showAlert('msg',
        'No course is assigned to you yet. Ask an admin to assign one from the admin console.', 'error');
    }

    const box = document.getElementById('teachingList');
    box.innerHTML = courses.length
      ? courses.map(c => `
        <div class="card">
          <div>
            <span class="tag">${esc(c.code)}</span>
            <span class="tag green">Published</span>
          </div>
          <h3 style="margin-top:7px">${esc(c.title)}</h3>
          <div class="stats" style="margin-top:11px">
            <div><b>${c.enrolledCount}</b><span>Enrolled</span></div>
            <div><b>${c.credits}</b><span>Credits</span></div>
          </div>
        </div>`).join('')
      : '<div class="empty">You do not teach any course yet.</div>';

  } catch (err) {
    setEmpty('teachingList', err.message);
  }

  loadEnrollRequests();
}

async function loadEnrollRequests() {
  try {
    const list = await API.get(api('courses'), { action: 'pendingEnrollments' });
    const box = document.getElementById('enrollRequests');
    box.innerHTML = list.length
      ? list.map(r => `
        <div class="card">
          <div class="card-row">
            <div class="avatar light">${initials(r.studentName)}</div>
            <div class="grow">
              <h3>${esc(r.studentName)}</h3>
              <div class="small">wants to join ${esc(r.courseCode)} - ${esc(r.courseTitle)}</div>
            </div>
          </div>
          <div class="btn-row" style="margin-top:11px">
            <button class="btn sm ghost" style="flex:1" onclick="decideEnrollment('rejectEnrollment', ${r.enrollmentId})">Reject</button>
            <button class="btn sm" style="flex:1" onclick="decideEnrollment('approveEnrollment', ${r.enrollmentId})">Approve</button>
          </div>
        </div>`).join('')
      : '<div class="empty">No enrollment request is waiting.</div>';
  } catch (err) {
    setEmpty('enrollRequests', err.message);
  }
}

async function decideEnrollment(action, enrollmentId) {
  try {
    await API.post(api('courses'), { action: action, enrollmentId: enrollmentId });
    loadEnrollRequests();
    loadInstructor();
  } catch (err) {
    alert(err.message);
  }
}

async function uploadMaterial(e) {
  e.preventDefault();
  hideAlert('msg');

  const file = document.getElementById('file').files[0];
  if (!file) { showAlert('msg', 'Choose a file first'); return; }

  const btn = document.getElementById('submitBtn');
  btn.disabled = true;
  btn.textContent = 'Uploading...';

  const form = new FormData();
  form.append('file', file);
  form.append('courseId', document.getElementById('courseId').value);
  form.append('type',     document.getElementById('type').value);
  form.append('title',    document.getElementById('title').value.trim());

  try {
    const r = await API.upload(api('materials'), form);
    showAlert('msg', r.message, 'ok');
    document.getElementById('title').value = '';
    document.getElementById('file').value = '';
  } catch (err) {
    showAlert('msg', err.message);
  }

  btn.disabled = false;
  btn.textContent = 'Upload for admin approval';
}

async function postOpportunity(e) {
  e.preventDefault();
  hideAlert('oppMsg');

  const title = document.getElementById('oppTitle').value.trim();
  if (!title) { showAlert('oppMsg', 'Give it a title'); return; }

  const btn = document.getElementById('oppSubmitBtn');
  btn.disabled = true;
  btn.textContent = 'Posting...';

  try {
    const r = await API.post(api('opportunities'), {
      action:      'create',
      title:       title,
      type:        document.getElementById('oppType').value,
      company:     document.getElementById('oppCompany').value.trim(),
      description: document.getElementById('oppDescription').value.trim(),
      stipend:     document.getElementById('oppStipend').value.trim(),
      deadline:    document.getElementById('oppDeadline').value,
      applyLink:   document.getElementById('oppLink').value.trim()
    });
    showAlert('oppMsg', r.message, 'ok');
    document.getElementById('oppTitle').value = '';
    document.getElementById('oppCompany').value = '';
    document.getElementById('oppDescription').value = '';
    document.getElementById('oppStipend').value = '';
    document.getElementById('oppDeadline').value = '';
    document.getElementById('oppLink').value = '';
  } catch (err) {
    showAlert('oppMsg', err.message);
  }

  btn.disabled = false;
  btn.textContent = 'Post to opportunity board';
}
