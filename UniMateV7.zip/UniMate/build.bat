@echo off
REM ============================================================
REM  UniMate - compile and deploy without an IDE
REM
REM  Before the first run, set TOMCAT below to your Tomcat folder
REM  (the one that contains bin, conf, lib and webapps).
REM ============================================================

set TOMCAT=C:\apache-tomcat-10.1.57

echo.
echo === Checking Tomcat ===
if not exist "%TOMCAT%\lib\servlet-api.jar" (
  echo.
  echo   Tomcat not found at %TOMCAT%
  echo   Open build.bat and fix the TOMCAT line at the top.
  echo.
  pause
  exit /b 1
)
echo   Found: %TOMCAT%

echo.
echo === Checking the jar files ===
if not exist "WebContent\WEB-INF\lib\*.jar" (
  echo.
  echo   No jars in WebContent\WEB-INF\lib
  echo   You need mysql-connector-j and gson there.
  echo.
  pause
  exit /b 1
)
echo   Found jars.

echo.
echo === Compiling Java ===
if exist "WebContent\WEB-INF\classes" rmdir /s /q "WebContent\WEB-INF\classes"
mkdir "WebContent\WEB-INF\classes"

dir /s /b src\*.java > sources.txt
javac -encoding UTF-8 ^
      -cp "%TOMCAT%\lib\*;WebContent\WEB-INF\lib\*" ^
      -d "WebContent\WEB-INF\classes" ^
      @sources.txt
del sources.txt

if errorlevel 1 (
  echo.
  echo   Compilation failed. Read the errors above.
  echo.
  pause
  exit /b 1
)
echo   Compiled.

echo.
echo === Deploying to Tomcat ===
if exist "%TOMCAT%\webapps\UniMate" rmdir /s /q "%TOMCAT%\webapps\UniMate"
xcopy /E /I /Q /Y "WebContent" "%TOMCAT%\webapps\UniMate" > nul
echo   Copied to %TOMCAT%\webapps\UniMate

echo.
echo   BUILD OK.  Deployment is complete.
echo.
