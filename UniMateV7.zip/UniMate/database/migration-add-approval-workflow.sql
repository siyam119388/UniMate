-- UniMate approval workflow migration for an existing database.
USE unimate;

-- New student/instructor registrations are already supported by the users.status column.
-- Convert existing seeded/uploaded materials to LIVE so old content remains visible.
ALTER TABLE materials ADD COLUMN status ENUM('PENDING','LIVE','REJECTED') NOT NULL DEFAULT 'LIVE' AFTER downloads;
UPDATE materials SET status = 'LIVE' WHERE status IS NULL OR status = '';

-- Existing marketplace photo migration remains separate in migration-add-photo.sql.
