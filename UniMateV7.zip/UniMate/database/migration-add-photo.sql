-- Run this once if you already created the database.
-- It adds the photo column that the marketplace now needs.

USE unimate;
ALTER TABLE market_items ADD COLUMN photo VARCHAR(120) AFTER seller_id;
