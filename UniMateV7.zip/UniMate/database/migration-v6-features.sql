-- UniMate v6 migration - run this once on an existing database.
-- Adds: enrollment approval workflow, group chat.
USE unimate;

-- 1) Enroll requests now need instructor approval.
--    Existing rows default to APPROVED so nobody already enrolled loses access.
ALTER TABLE enrollments ADD COLUMN status ENUM('PENDING','APPROVED') NOT NULL DEFAULT 'PENDING' AFTER course_id;
UPDATE enrollments SET status = 'APPROVED';
ALTER TABLE enrollments ALTER COLUMN status SET DEFAULT 'PENDING';

-- 2) Group chat.
CREATE TABLE IF NOT EXISTS group_messages (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    group_id   INT NOT NULL,
    sender_id  INT NOT NULL,
    message    VARCHAR(1000) NOT NULL,
    sent_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (group_id)  REFERENCES study_groups(group_id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(user_id)         ON DELETE CASCADE
);
