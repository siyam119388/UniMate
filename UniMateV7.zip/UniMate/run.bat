@echo off
REM ============================================================
REM  UniMate - build, start Tomcat, open the browser
REM ============================================================

set TOMCAT=C:\apache-tomcat-10.1.57

call build.bat
if errorlevel 1 exit /b 1

echo.
echo === Starting Tomcat ===
//start "" "%TOMCAT%\bin\startup.bat"
set CATALINA_HOME=%TOMCAT%
start "Tomcat" /D "%TOMCAT%\bin" cmd /c catalina.bat run

echo   Waiting for the server...
timeout /t 8 /nobreak > nul

start "" http://localhost:8080/UniMate/

echo.
echo   UniMate is running at  http://localhost:8080/UniMate/
echo   Close the Tomcat window to stop it, or run stop.bat
echo.
pause
