package com.unimate.dao;

import com.unimate.model.GroupMessage;
import com.unimate.model.StudyGroup;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class GroupDAO implements BaseDAO<StudyGroup> {

    private StudyGroup build(ResultSet rs) throws SQLException {
        StudyGroup g = new StudyGroup();
        g.setGroupId(rs.getInt("group_id"));
        g.setName(rs.getString("name"));
        g.setCourseCode(rs.getString("course_code"));
        g.setUniversity(rs.getString("university"));
        g.setDescription(rs.getString("description"));
        g.setMaxMembers(rs.getInt("max_members"));
        g.setCreatedBy(rs.getInt("created_by"));
        g.setMemberCount(rs.getInt("member_count"));
        return g;
    }

    private static final String SELECT =
        "SELECT g.*, (SELECT COUNT(*) FROM group_members m WHERE m.group_id = g.group_id) "
      + "AS member_count FROM study_groups g ";

    @Override
    public List<StudyGroup> findAll() throws SQLException {
        List<StudyGroup> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT + "ORDER BY g.group_id DESC")) {
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public StudyGroup findById(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(SELECT + "WHERE g.group_id = ?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? build(rs) : null;
        }
    }

    @Override
    public boolean insert(StudyGroup g) throws SQLException {
        String sql = "INSERT INTO study_groups (name, course_code, university, description, "
                   + "max_members, created_by) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, g.getName());
            ps.setString(2, g.getCourseCode());
            ps.setString(3, g.getUniversity());
            ps.setString(4, g.getDescription());
            ps.setInt(5, g.getMaxMembers());
            ps.setInt(6, g.getCreatedBy());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean join(int groupId, int studentId) throws SQLException {
        String sql = "INSERT IGNORE INTO group_members (group_id, student_id) VALUES (?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, groupId);
            ps.setInt(2, studentId);
            return ps.executeUpdate() == 1;
        }
    }

    public List<StudyGroup> findByStudent(int studentId) throws SQLException {
        List<StudyGroup> list = new ArrayList<>();
        String sql = SELECT + "JOIN group_members m ON m.group_id = g.group_id "
                   + "WHERE m.student_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    public boolean isMember(int groupId, int studentId) throws SQLException {
        String sql = "SELECT 1 FROM group_members WHERE group_id = ? AND student_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, groupId);
            ps.setInt(2, studentId);
            return ps.executeQuery().next();
        }
    }

    /** Each member as a small {userId, name} map - enough for the chat header. */
    public List<Map<String, Object>> findMembers(int groupId) throws SQLException {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT u.user_id, u.name FROM group_members m "
                   + "JOIN users u ON u.user_id = m.student_id "
                   + "WHERE m.group_id = ? ORDER BY m.joined_at";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, groupId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("userId", rs.getInt("user_id"));
                m.put("name", rs.getString("name"));
                list.add(m);
            }
        }
        return list;
    }

    public boolean sendMessage(int groupId, int senderId, String message) throws SQLException {
        String sql = "INSERT INTO group_messages (group_id, sender_id, message) VALUES (?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, groupId);
            ps.setInt(2, senderId);
            ps.setString(3, message);
            return ps.executeUpdate() == 1;
        }
    }

    public List<GroupMessage> findMessages(int groupId) throws SQLException {
        List<GroupMessage> list = new ArrayList<>();
        String sql = "SELECT gm.*, u.name AS sender_name FROM group_messages gm "
                   + "JOIN users u ON u.user_id = gm.sender_id "
                   + "WHERE gm.group_id = ? ORDER BY gm.message_id";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, groupId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                GroupMessage m = new GroupMessage();
                m.setMessageId(rs.getInt("message_id"));
                m.setGroupId(rs.getInt("group_id"));
                m.setSenderId(rs.getInt("sender_id"));
                m.setSenderName(rs.getString("sender_name"));
                m.setMessage(rs.getString("message"));
                m.setSentAt(String.valueOf(rs.getTimestamp("sent_at")));
                list.add(m);
            }
        }
        return list;
    }
}
