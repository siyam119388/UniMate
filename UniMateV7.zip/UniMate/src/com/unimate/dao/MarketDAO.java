package com.unimate.dao;

import com.unimate.model.MarketItem;
import com.unimate.util.Constants;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MarketDAO implements BaseDAO<MarketItem> {

    private MarketItem build(ResultSet rs) throws SQLException {
        MarketItem i = new MarketItem();
        i.setItemId(rs.getInt("item_id"));
        i.setTitle(rs.getString("title"));
        i.setDescription(rs.getString("description"));
        i.setCategory(rs.getString("category"));
        i.setPrice(rs.getDouble("price"));
        i.setItemCondition(rs.getString("item_condition"));
        i.setPickupPoint(rs.getString("pickup_point"));
        i.setStatus(rs.getString("status"));
        i.setSellerId(rs.getInt("seller_id"));
        i.setSellerName(rs.getString("seller_name"));
        i.setPhoto(rs.getString("photo"));
        return i;
    }

    private static final String SELECT =
        "SELECT i.*, u.name AS seller_name FROM market_items i "
      + "LEFT JOIN users u ON u.user_id = i.seller_id ";

    /** Students only ever see LIVE items. */
    public List<MarketItem> findLive() throws SQLException {
        return findByStatus(Constants.ITEM_LIVE);
    }

    public List<MarketItem> findByStatus(String status) throws SQLException {
        List<MarketItem> list = new ArrayList<>();
        String sql = SELECT + "WHERE i.status = ? ORDER BY i.item_id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public MarketItem findById(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(SELECT + "WHERE i.item_id = ?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? build(rs) : null;
        }
    }

    @Override
    public List<MarketItem> findAll() throws SQLException {
        List<MarketItem> list = new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(SELECT + "ORDER BY i.item_id DESC")) {
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public boolean insert(MarketItem i) throws SQLException {
        String sql = "INSERT INTO market_items (title, description, category, price, "
                   + "item_condition, pickup_point, status, seller_id, photo) "
                   + "VALUES (?,?,?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, i.getTitle());
            ps.setString(2, i.getDescription());
            ps.setString(3, i.getCategory());
            ps.setDouble(4, i.getPrice());
            ps.setString(5, i.getItemCondition());
            ps.setString(6, i.getPickupPoint());
            ps.setString(7, Constants.ITEM_PENDING);   // always waits for an admin
            ps.setInt(8, i.getSellerId());
            ps.setString(9, i.getPhoto());
            return ps.executeUpdate() == 1;
        }
    }

    public List<MarketItem> findBySeller(int sellerId) throws SQLException {
        List<MarketItem> list = new ArrayList<>();
        String sql = SELECT + "WHERE i.seller_id = ? ORDER BY i.item_id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, sellerId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    public boolean updateStatus(int itemId, String status) throws SQLException {
        String sql = "UPDATE market_items SET status = ? WHERE item_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, itemId);
            return ps.executeUpdate() == 1;
        }
    }
}
