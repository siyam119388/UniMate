package com.unimate.dao;

import com.unimate.model.Material;
import com.unimate.util.Constants;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MaterialDAO implements BaseDAO<Material> {

    private Material build(ResultSet rs) throws SQLException {
        Material m = new Material();
        m.setMaterialId(rs.getInt("material_id"));
        m.setCourseId(rs.getInt("course_id"));
        m.setCourseCode(rs.getString("course_code"));
        m.setType(rs.getString("type"));
        m.setTitle(rs.getString("title"));
        m.setFilePath(rs.getString("file_path"));
        m.setUploadedBy(rs.getInt("uploaded_by"));
        m.setUploaderName(rs.getString("uploader_name"));
        m.setDownloads(rs.getInt("downloads"));
        m.setStatus(rs.getString("status"));
        return m;
    }

    private static final String SELECT =
        "SELECT m.*, c.code AS course_code, u.name AS uploader_name " +
        "FROM materials m " +
        "JOIN courses c ON c.course_id = m.course_id " +
        "LEFT JOIN users u ON u.user_id = m.uploaded_by ";

    public List<Material> findByCourse(int courseId) throws SQLException {
        List<Material> list = new ArrayList<>();
        String sql = SELECT + "WHERE m.course_id = ? AND m.status = ? ORDER BY m.material_id DESC";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, courseId);
            ps.setString(2, Constants.MATERIAL_LIVE);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public Material findById(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(SELECT + "WHERE m.material_id = ?")) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? build(rs) : null;
        }
    }

    @Override
    public List<Material> findAll() throws SQLException {
        return findByStatus(null);
    }

    public List<Material> findByStatus(String status) throws SQLException {
        List<Material> list = new ArrayList<>();
        String sql = SELECT + (status == null ? "ORDER BY m.material_id DESC" : "WHERE m.status = ? ORDER BY m.material_id DESC");
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (status != null) ps.setString(1, status);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public boolean insert(Material m) throws SQLException {
        String sql = "INSERT INTO materials (course_id, type, title, file_path, uploaded_by, status) VALUES (?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, m.getCourseId());
            ps.setString(2, m.getType());
            ps.setString(3, m.getTitle());
            ps.setString(4, m.getFilePath());
            ps.setInt(5, m.getUploadedBy());
            ps.setString(6, Constants.MATERIAL_PENDING);
            return ps.executeUpdate() == 1;
        }
    }

    public boolean updateStatus(int materialId, String status) throws SQLException {
        String sql = "UPDATE materials SET status = ? WHERE material_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, materialId);
            return ps.executeUpdate() == 1;
        }
    }

    public void countDownload(int materialId) throws SQLException {
        String sql = "UPDATE materials SET downloads = downloads + 1 WHERE material_id = ?";
        try (Connection c = DBConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, materialId);
            ps.executeUpdate();
        }
    }
}
