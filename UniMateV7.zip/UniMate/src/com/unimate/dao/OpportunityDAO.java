package com.unimate.dao;

import com.unimate.model.Opportunity;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OpportunityDAO implements BaseDAO<Opportunity> {

    private Opportunity build(ResultSet rs) throws SQLException {
        Opportunity o = new Opportunity();
        o.setOpportunityId(rs.getInt("opportunity_id"));
        o.setTitle(rs.getString("title"));
        o.setType(rs.getString("type"));
        o.setCompany(rs.getString("company"));
        o.setDescription(rs.getString("description"));
        o.setStipend(rs.getString("stipend"));
        o.setDeadline(rs.getString("deadline"));
        o.setApplyLink(rs.getString("apply_link"));
        return o;
    }

    @Override
    public List<Opportunity> findAll() throws SQLException {
        List<Opportunity> list = new ArrayList<>();
        String sql = "SELECT * FROM opportunities ORDER BY deadline ASC";
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    public List<Opportunity> findByType(String type) throws SQLException {
        List<Opportunity> list = new ArrayList<>();
        String sql = "SELECT * FROM opportunities WHERE type = ? ORDER BY deadline ASC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, type);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public Opportunity findById(int id) throws SQLException {
        String sql = "SELECT * FROM opportunities WHERE opportunity_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? build(rs) : null;
        }
    }

    @Override
    public boolean insert(Opportunity o) throws SQLException {
        String sql = "INSERT INTO opportunities (title, type, company, description, stipend, "
                   + "deadline, apply_link) VALUES (?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, o.getTitle());
            ps.setString(2, o.getType());
            ps.setString(3, o.getCompany());
            ps.setString(4, o.getDescription());
            ps.setString(5, o.getStipend());
            ps.setString(6, o.getDeadline());
            ps.setString(7, o.getApplyLink());
            return ps.executeUpdate() == 1;
        }
    }
}
