package com.unimate.dao;

import com.unimate.model.*;
import com.unimate.util.Constants;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO implements BaseDAO<User> {

    /** Turns one database row into the right subclass. */
    private User build(ResultSet rs) throws SQLException {
        String role = rs.getString("role");
        User u;

        if (Constants.ROLE_INSTRUCTOR.equals(role)) {
            Instructor i = new Instructor();
            i.setDesignation(rs.getString("designation"));
            u = i;
        } else if (Constants.ROLE_ADMIN.equals(role)) {
            u = new Admin();
        } else {
            Student s = new Student();
            s.setStudentId(rs.getString("student_id"));
            s.setSemester(rs.getString("semester"));
            u = s;
        }

        u.setUserId(rs.getInt("user_id"));
        u.setName(rs.getString("name"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setUniversity(rs.getString("university"));
        u.setDepartment(rs.getString("department"));
        u.setStatus(rs.getString("status"));
        return u;
    }

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? build(rs) : null;
        }
    }

    @Override
    public User findById(int id) throws SQLException {
        String sql = "SELECT * FROM users WHERE user_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? build(rs) : null;
        }
    }

    @Override
    public List<User> findAll() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY user_id DESC";
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    public List<User> findPending() throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE status = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, Constants.STATUS_PENDING);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    public List<User> findByRole(String role) throws SQLException {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE role = ? AND status = ? ORDER BY name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, role);
            ps.setString(2, Constants.STATUS_ACTIVE);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(build(rs));
        }
        return list;
    }

    @Override
    public boolean insert(User u) throws SQLException {
        String sql = "INSERT INTO users (name, email, password_hash, role, university, "
                   + "department, student_id, designation, semester, status) "
                   + "VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, u.getName());
            ps.setString(2, u.getEmail());
            ps.setString(3, u.getPasswordHash());
            ps.setString(4, u.getRole());
            ps.setString(5, u.getUniversity());
            ps.setString(6, u.getDepartment());
            ps.setString(7, (u instanceof Student) ? ((Student) u).getStudentId() : null);
            ps.setString(8, (u instanceof Instructor) ? ((Instructor) u).getDesignation() : null);
            ps.setString(9, (u instanceof Student) ? ((Student) u).getSemester() : null);
           String status = u.getStatus();

if (status == null || status.trim().isEmpty()) {
    status = Constants.STATUS_PENDING;
}

ps.setString(10, status);
return ps.executeUpdate() == 1;
        }
    }

    public boolean updateStatus(int userId, String status) throws SQLException {
        String sql = "UPDATE users SET status = ? WHERE user_id = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, userId);
            return ps.executeUpdate() == 1;
        }
    }
}
