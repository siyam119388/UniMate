package com.unimate.filter;

import com.unimate.model.User;
import com.unimate.util.Constants;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;

/** Blocks a page when there is no session, or when the role does not match the folder. */
@WebFilter({"/student/*", "/instructor/*", "/admin/*"})
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req  = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        HttpSession session = req.getSession(false);
        User user = (session == null) ? null : (User) session.getAttribute("user");

        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/index.html");
            return;
        }

        String path = req.getRequestURI();
        String role = user.getRole();

        boolean allowed =
              (path.contains("/student/")    && Constants.ROLE_STUDENT.equals(role))
           || (path.contains("/instructor/") && Constants.ROLE_INSTRUCTOR.equals(role))
           || (path.contains("/admin/")      && Constants.ROLE_ADMIN.equals(role));

        if (!allowed) {
            res.sendRedirect(req.getContextPath() + "/" + user.getDashboardPath());
            return;
        }

        chain.doFilter(request, response);
    }
}
