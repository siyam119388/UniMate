package com.unimate.model;

import com.unimate.util.Constants;

public class Admin extends User {

    public Admin() {
        super(Constants.ROLE_ADMIN, "admin/dashboard.html");
    }
}
