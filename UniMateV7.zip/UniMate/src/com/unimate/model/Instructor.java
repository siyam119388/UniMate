package com.unimate.model;

import com.unimate.util.Constants;

public class Instructor extends User {

    private String designation;

    public Instructor() {
        super(Constants.ROLE_INSTRUCTOR, "instructor/dashboard.html");
    }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }
}
