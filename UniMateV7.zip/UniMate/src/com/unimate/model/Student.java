package com.unimate.model;

import com.unimate.util.Constants;

public class Student extends User {

    private String studentId;
    private String semester;

    public Student() {
        super(Constants.ROLE_STUDENT, "student/dashboard.html");
    }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
}
