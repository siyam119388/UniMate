package com.unimate.servlet;

import com.unimate.dao.CourseDAO;
import com.unimate.dao.MaterialDAO;
import com.unimate.model.Course;
import com.unimate.model.Material;
import com.unimate.model.User;
import com.unimate.util.AIService;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;

/**
 * Study assistant.
 * It gathers the titles of the student's course materials, sends them to the
 * language model as context, and returns the answer with the closest source.
 */
@WebServlet("/ai")
public class AIServlet extends BaseServlet {

    private final CourseDAO courseDAO = new CourseDAO();
    private final MaterialDAO materialDAO = new MaterialDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String question = req.getParameter("question");
        if (question == null || question.trim().isEmpty()) {
            sendError(res, 400, "Ask a question first");
            return;
        }

        try {
            // the student's own courses, or every course if they have not enrolled yet
            List<Course> courses = courseDAO.findByStudent(user.getUserId());
            boolean usingAllCourses = courses.isEmpty();
            if (usingAllCourses) courses = courseDAO.findAll();

            StringBuilder context = new StringBuilder();
            Material best = null;
            int bestScore = 0;

            for (Course c : courses) {
                for (Material m : materialDAO.findByCourse(c.getCourseId())) {
                    context.append("- ").append(c.getCode()).append(" ")
                           .append(c.getTitle()).append(" : ")
                           .append(m.getTitle()).append("\n");

                    int score = score(question, m.getTitle() + " " + c.getCode() + " " + c.getTitle());
                    if (score > bestScore) { bestScore = score; best = m; }
                }
            }

            String answer = AIService.ask(question, context.toString());

            Map<String, Object> out = new HashMap<>();
            out.put("answer", answer);
            out.put("source", bestScore > 0 ? best : null);
            out.put("scope", usingAllCourses ? "all courses" : "your enrolled courses");
            sendJson(res, out);

        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }

    /** How many words of the question appear in the material title. */
    private int score(String question, String text) {
        int hits = 0;
        String lower = text.toLowerCase();
        for (String word : question.toLowerCase().split("\\s+")) {
            if (word.length() > 3 && lower.contains(word)) hits++;
        }
        return hits;
    }
}
