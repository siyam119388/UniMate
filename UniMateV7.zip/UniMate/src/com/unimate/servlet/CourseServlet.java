package com.unimate.servlet;

import com.unimate.dao.CourseDAO;
import com.unimate.model.Course;
import com.unimate.model.User;
import com.unimate.util.Constants;
import com.unimate.util.JsonUtil;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/courses")
public class CourseServlet extends BaseServlet {

    private final CourseDAO courseDAO = new CourseDAO();

    /** ?action=list | detail | mine | teaching | pendingEnrollments */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String action = req.getParameter("action");
        try {
            if ("detail".equals(action)) {
                Course c = courseDAO.findById(intParam(req, "id"));
                if (c != null && Constants.ROLE_STUDENT.equals(user.getRole())) {
                    String status = courseDAO.getEnrollmentStatus(user.getUserId(), c.getCourseId());
                    c.setEnrollmentStatus(status == null ? "NONE" : status);
                }
                sendJson(res, c);
            } else if ("mine".equals(action)) {
                sendJson(res, courseDAO.findByStudent(user.getUserId()));
            } else if ("teaching".equals(action)) {
                sendJson(res, courseDAO.findByInstructor(user.getUserId()));
            } else if ("pendingEnrollments".equals(action)) {
                if (!Constants.ROLE_INSTRUCTOR.equals(user.getRole())) {
                    sendError(res, 403, "Instructors only"); return;
                }
                sendJson(res, courseDAO.findPendingByInstructor(user.getUserId()));
            } else {
                sendJson(res, courseDAO.search(req.getParameter("q")));
            }
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }

    /** action=create for instructors, approveEnrollment/rejectEnrollment for instructors,
     *  otherwise a student's enroll request. */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String action = req.getParameter("action");
        try {
            if ("create".equals(action)) {
                if (!Constants.ROLE_INSTRUCTOR.equals(user.getRole())) {
                    sendError(res, 403, "Only instructors can create a course");
                    return;
                }
                Course c = new Course();
                c.setCode(req.getParameter("code"));
                c.setTitle(req.getParameter("title"));
                c.setCredits(intParam(req, "credits"));
                c.setPrerequisites(req.getParameter("prerequisites"));
                c.setDifficulty(req.getParameter("difficulty"));
                c.setDescription(req.getParameter("description"));
                c.setInstructorId(user.getUserId());
                sendJson(res, JsonUtil.message(
                        courseDAO.insert(c) ? "Course created" : "Could not create the course"));
                return;
            }

            if ("approveEnrollment".equals(action) || "rejectEnrollment".equals(action)) {
                if (!Constants.ROLE_INSTRUCTOR.equals(user.getRole())) {
                    sendError(res, 403, "Instructors only"); return;
                }
                int enrollmentId = intParam(req, "enrollmentId");
                boolean ok = "approveEnrollment".equals(action)
                        ? courseDAO.approveEnrollment(enrollmentId, user.getUserId())
                        : courseDAO.rejectEnrollment(enrollmentId, user.getUserId());
                sendJson(res, JsonUtil.message(ok ? "Done" : "That request is not yours to decide"));
                return;
            }

            boolean ok = courseDAO.requestEnroll(user.getUserId(), intParam(req, "courseId"));
            sendJson(res, JsonUtil.message(ok ? "Enrollment request sent" : "Already requested or enrolled"));
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }
}
