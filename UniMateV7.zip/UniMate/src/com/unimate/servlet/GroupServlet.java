package com.unimate.servlet;

import com.unimate.dao.GroupDAO;
import com.unimate.model.StudyGroup;
import com.unimate.model.User;
import com.unimate.util.Constants;
import com.unimate.util.JsonUtil;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/groups")
public class GroupServlet extends BaseServlet {

    private final GroupDAO groupDAO = new GroupDAO();

    /** ?action=detail | mine | members | messages */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String action = req.getParameter("action");
        try {
            if ("detail".equals(action)) {
                StudyGroup g = groupDAO.findById(intParam(req, "id"));
                if (g != null && Constants.ROLE_STUDENT.equals(user.getRole())) {
                    g.setMember(groupDAO.isMember(g.getGroupId(), user.getUserId()));
                }
                sendJson(res, g);
            } else if ("mine".equals(action)) {
                sendJson(res, groupDAO.findByStudent(user.getUserId()));
            } else if ("members".equals(action)) {
                int groupId = intParam(req, "groupId");
                if (!groupDAO.isMember(groupId, user.getUserId())) {
                    sendError(res, 403, "Join the group to see its members"); return;
                }
                sendJson(res, groupDAO.findMembers(groupId));
            } else if ("messages".equals(action)) {
                int groupId = intParam(req, "groupId");
                if (!groupDAO.isMember(groupId, user.getUserId())) {
                    sendError(res, 403, "Join the group to see the chat"); return;
                }
                sendJson(res, groupDAO.findMessages(groupId));
            } else {
                sendJson(res, groupDAO.findAll());
            }
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }

    /** action=create, join or sendMessage */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String action = req.getParameter("action");
        try {
            if ("join".equals(action)) {
                boolean ok = groupDAO.join(intParam(req, "groupId"), user.getUserId());
                sendJson(res, JsonUtil.message(ok ? "Joined" : "Already a member"));
                return;
            }

            if ("sendMessage".equals(action)) {
                int groupId = intParam(req, "groupId");
                String message = req.getParameter("message");
                if (!groupDAO.isMember(groupId, user.getUserId())) {
                    sendError(res, 403, "Join the group to chat here"); return;
                }
                if (message == null || message.trim().isEmpty()) {
                    sendError(res, 400, "Type a message first"); return;
                }
                groupDAO.sendMessage(groupId, user.getUserId(), message.trim());
                sendJson(res, JsonUtil.message("Sent"));
                return;
            }

            StudyGroup g = new StudyGroup();
            g.setName(req.getParameter("name"));
            g.setCourseCode(req.getParameter("courseCode"));
            g.setUniversity(req.getParameter("university"));
            g.setDescription(req.getParameter("description"));
            g.setMaxMembers(intParam(req, "maxMembers"));
            g.setCreatedBy(user.getUserId());

            sendJson(res, JsonUtil.message(groupDAO.insert(g) ? "Group created" : "Failed"));
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }
}
