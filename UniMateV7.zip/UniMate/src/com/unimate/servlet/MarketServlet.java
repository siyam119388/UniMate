package com.unimate.servlet;

import com.unimate.dao.MarketDAO;
import com.unimate.model.MarketItem;
import com.unimate.model.User;
import com.unimate.util.Constants;
import com.unimate.util.JsonUtil;

import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@WebServlet("/marketplace")
@MultipartConfig(maxFileSize = 5 * 1024 * 1024)   // 5 MB per photo
public class MarketServlet extends BaseServlet {

    private final MarketDAO marketDAO = new MarketDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String action = req.getParameter("action");
        try {
            // stream a photo back to the browser
            if ("photo".equals(action)) {
                String name = req.getParameter("name");
                if (name == null || name.contains("..") || name.contains("/")) {
                    sendError(res, 400, "Bad file name"); return;
                }
                File f = new File(Constants.ITEM_DIR, name);
                if (!f.exists()) { sendError(res, 404, "No photo"); return; }
                res.setContentType(Files.probeContentType(f.toPath()));
                Files.copy(f.toPath(), res.getOutputStream());
                return;
            }

            if ("detail".equals(action)) {
                sendJson(res, marketDAO.findById(intParam(req, "id")));
            } else if ("mine".equals(action)) {
                sendJson(res, marketDAO.findBySeller(user.getUserId()));
            } else {
                sendJson(res, marketDAO.findLive());
            }
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String action = req.getParameter("action");
        try {
            if ("purchase".equals(action)) {
                int itemId = intParam(req, "id");
                MarketItem item = marketDAO.findById(itemId);
                if (item == null || !Constants.ITEM_LIVE.equals(item.getStatus())) {
                    sendError(res, 400, "This item is no longer available"); return;
                }
                if (item.getSellerId() == user.getUserId()) {
                    sendError(res, 400, "You cannot buy your own listing"); return;
                }
                boolean ok = marketDAO.updateStatus(itemId, Constants.ITEM_SOLD);
                sendJson(res, JsonUtil.message(ok
                        ? "Purchase confirmed - pay the seller cash on pickup. The item is now marked sold."
                        : "Could not complete the purchase"));
                return;
            }

            String title = req.getParameter("title");
            double price = doubleParam(req, "price");

            if (title == null || title.trim().isEmpty()) {
                sendError(res, 400, "Give the item a title"); return;
            }
            if (price <= 0) {
                sendError(res, 400, "Enter a price above zero"); return;
            }

            // optional photo
            String photoName = null;
            try {
                Part part = req.getPart("photo");
                if (part != null && part.getSize() > 0) {
                    String original = part.getSubmittedFileName();
                    String ext = original.contains(".")
                            ? original.substring(original.lastIndexOf('.')).toLowerCase() : ".jpg";
                    if (!".jpg.jpeg.png.webp".contains(ext)) {
                        sendError(res, 400, "Photos must be jpg, png or webp"); return;
                    }
                    photoName = "item_" + System.currentTimeMillis() + ext;
                    Constants.folder(Constants.ITEM_DIR);
                    part.write(Constants.ITEM_DIR + File.separator + photoName);
                }
            } catch (Exception ignore) {
                // form was sent without a file part - that is allowed
            }

            MarketItem i = new MarketItem();
            i.setTitle(title.trim());
            i.setDescription(req.getParameter("description"));
            i.setCategory(req.getParameter("category"));
            i.setPrice(price);
            i.setItemCondition(req.getParameter("condition"));
            i.setPickupPoint(req.getParameter("pickupPoint"));
            i.setSellerId(user.getUserId());
            i.setPhoto(photoName);

            sendJson(res, JsonUtil.message(
                marketDAO.insert(i) ? "Sent for admin review" : "Could not post the item"));

        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }
}
