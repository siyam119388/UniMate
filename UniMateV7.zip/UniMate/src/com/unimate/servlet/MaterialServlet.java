package com.unimate.servlet;

import com.unimate.dao.CourseDAO;
import com.unimate.dao.MaterialDAO;
import com.unimate.model.Material;
import com.unimate.model.User;
import com.unimate.util.Constants;
import com.unimate.util.JsonUtil;

import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

@WebServlet("/materials")
@MultipartConfig(maxFileSize = 25 * 1024 * 1024)
public class MaterialServlet extends BaseServlet {

    private final MaterialDAO materialDAO = new MaterialDAO();
    private final CourseDAO courseDAO = new CourseDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        try {
            if ("download".equals(req.getParameter("action"))) {
                Material m = materialDAO.findById(intParam(req, "id"));
                if (m == null || !Constants.MATERIAL_LIVE.equals(m.getStatus())) {
                    sendError(res, 404, "File not found"); return;
                }

                boolean allowed = Constants.ROLE_ADMIN.equals(user.getRole())
                        || (Constants.ROLE_INSTRUCTOR.equals(user.getRole())
                            && courseDAO.isInstructorOfCourse(user.getUserId(), m.getCourseId()))
                        || (Constants.ROLE_STUDENT.equals(user.getRole())
                            && courseDAO.isEnrolled(user.getUserId(), m.getCourseId()));
                if (!allowed) { sendError(res, 403, "You do not have access to this material"); return; }

                File file = new File(Constants.MATERIAL_DIR, new File(m.getFilePath()).getName());
                if (!file.exists()) {
                    sendError(res, 404, "The file is missing on the server. Ask the instructor to upload it again.");
                    return;
                }
                res.setContentType("application/octet-stream");
                res.setHeader(
    "Content-Disposition",
    "attachment; filename=\"" + file.getName().replace("\"", "") + "\""
);

Files.copy(file.toPath(), res.getOutputStream());

materialDAO.countDownload(m.getMaterialId());

return;
            }

            int courseId = intParam(req, "courseId");
            sendJson(res, materialDAO.findByCourse(courseId));
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null || !Constants.ROLE_INSTRUCTOR.equals(user.getRole())) {
            sendError(res, 403, "Only instructors can upload"); return;
        }

        try {
            int courseId = intParam(req, "courseId");
            String title = req.getParameter("title");
            if (courseId == 0 || !courseDAO.isInstructorOfCourse(user.getUserId(), courseId)) {
                sendError(res, 403, "You can only upload materials to a course you teach"); return;
            }
            if (title == null || title.trim().isEmpty()) {
                sendError(res, 400, "Give the material a title"); return;
            }

            Part part = req.getPart("file");
            if (part == null || part.getSize() == 0) {
                sendError(res, 400, "Choose a file to upload"); return;
            }
            String original = part.getSubmittedFileName();
            String ext = original != null && original.contains(".")
                    ? original.substring(original.lastIndexOf('.')).toLowerCase() : "";
            if (!(ext.equals(".pdf") || ext.equals(".ppt") || ext.equals(".pptx") || ext.equals(".doc") || ext.equals(".docx") || ext.equals(".zip"))) {
                sendError(res, 400, "Allowed files: PDF, PPT, PPTX, DOC, DOCX or ZIP"); return;
            }

            String safe = (original == null ? "file" : original).replaceAll("[^A-Za-z0-9._-]", "_");
            String stored = System.currentTimeMillis() + "_" + safe;
            Constants.folder(Constants.MATERIAL_DIR);
            part.write(Constants.MATERIAL_DIR + File.separator + stored);

            Material m = new Material();
            m.setCourseId(courseId);
            m.setType(req.getParameter("type"));
            m.setTitle(title.trim());
            m.setFilePath(stored);
            m.setUploadedBy(user.getUserId());

            if (!materialDAO.insert(m)) {
                new File(Constants.MATERIAL_DIR, stored).delete();
                sendError(res, 500, "Upload failed"); return;
            }
            sendJson(res, JsonUtil.message("Uploaded and sent for admin review"));
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }
}
