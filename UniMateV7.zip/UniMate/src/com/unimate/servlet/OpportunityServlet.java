package com.unimate.servlet;

import com.unimate.dao.OpportunityDAO;
import com.unimate.model.Opportunity;
import com.unimate.model.User;
import com.unimate.util.Constants;
import com.unimate.util.JsonUtil;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/opportunities")
public class OpportunityServlet extends BaseServlet {

    private final OpportunityDAO dao = new OpportunityDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }

        String type = req.getParameter("type");
        try {
            if ("detail".equals(req.getParameter("action"))) {
                sendJson(res, dao.findById(intParam(req, "id")));
            } else if (type != null && !type.isEmpty()) {
                sendJson(res, dao.findByType(type));
            } else {
                sendJson(res, dao.findAll());
            }
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }

    /** Instructors and admins can post a hackathon, internship, scholarship or contest. */
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
        User user = currentUser(req);
        if (user == null) { sendError(res, 401, "Please log in"); return; }
        if (!Constants.ROLE_INSTRUCTOR.equals(user.getRole()) && !Constants.ROLE_ADMIN.equals(user.getRole())) {
            sendError(res, 403, "Only instructors and admins can post an opportunity"); return;
        }

        try {
            String title = req.getParameter("title");
            if (title == null || title.trim().isEmpty()) {
                sendError(res, 400, "Give it a title"); return;
            }
            Opportunity o = new Opportunity();
            o.setTitle(title.trim());
            o.setType(req.getParameter("type"));
            o.setCompany(req.getParameter("company"));
            o.setDescription(req.getParameter("description"));
            o.setStipend(req.getParameter("stipend"));
            o.setDeadline(req.getParameter("deadline"));
            o.setApplyLink(req.getParameter("applyLink"));
            sendJson(res, JsonUtil.message(
                    dao.insert(o) ? "Posted to the opportunity board" : "Could not post it"));
        } catch (Exception e) {
            sendError(res, 500, e.getMessage());
        }
    }
}
