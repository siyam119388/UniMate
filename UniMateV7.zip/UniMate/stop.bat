@echo off
set TOMCAT=C:\apache-tomcat-10.1.57
call "%TOMCAT%\bin\shutdown.bat"
echo Tomcat stopped.
pause
